plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nov3x.gamespace"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nov3x.gamespace"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
